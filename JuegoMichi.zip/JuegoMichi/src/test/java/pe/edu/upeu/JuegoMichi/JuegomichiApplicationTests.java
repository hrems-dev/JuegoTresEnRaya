package pe.edu.upeu.JuegoMichi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JuegomichiApplicationTests {

	@Test
	void contextLoads() {
	}

}
