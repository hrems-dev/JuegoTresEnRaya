package pe.edu.upeu.JuegoMichi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JuegomichiApplication {

	public static void main(String[] args) {
		SpringApplication.run(JuegomichiApplication.class, args);
	}

}
